package application;

public class items {
private String iname,brand,category,size,price,quantity = null;

items(){
	
}

public items(String iname,String brand,String category, String size,String price, String quantity){
	this.iname = iname;
	this.brand = brand;
	this.category = category;
	this.size = size;
	this.price = price;
	this.quantity = quantity;

}

public String getIname() {
	return iname;
}

public void setIname(String iname) {
	this.iname = iname;
}

public String getBrand() {
	return brand;
}

public void setBrand(String brand) {
	this.brand = brand;
}

public String getCategory() {
	return category;
}

public void setCategory(String category) {
	this.category = category;
}

public String getSize() {
	return size;
}

public void setSize(String size) {
	this.size = size;
}

public String getPrice() {
	return price;
}

public void setPrice(String price) {
	this.price = price;
}

public String getQuantity() {
	return quantity;
}

public void setQuantity(String quantity) {
	this.quantity = quantity;
}


}
