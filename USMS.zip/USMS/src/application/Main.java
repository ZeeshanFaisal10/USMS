package application;
	
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import com.sun.javafx.scene.layout.region.Margins.Converter;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ListChangeListener.Change;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TableView.TableViewSelectionModel;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;


public class Main extends Application {
	

Scene scene1, scene2;
ComboBox tf1;
String val = "";
int index;
int count = 0;
ListView list , stocklist;
TableView<items> tableView;
TableView<Stock> StockView;
TextField tf3;
String itemid = "";

	@Override
	public void start(Stage primaryStage) {
        
primaryStage.setTitle("Welcome to USMS");

//Scene 1
GridPane grid = new GridPane();
grid.setAlignment(Pos.CENTER);
grid.setHgap(10);
grid.setVgap(10);
grid.setPadding(new Insets(10));

Text text = new Text("Welcome");
text.setFont(Font.font("Serif",FontWeight.LIGHT,30));
grid.add(text, 0, 0);

Label username = new Label("Username");
grid.add(username, 0, 1);

TextField txt_user = new TextField();
txt_user.setPromptText("Enter username");
grid.add(txt_user, 1, 1);

Label password = new Label("Password");
grid.add(password, 0, 2);

TextField txt_pass = new TextField();
txt_pass.setPromptText("Enter password");
grid.add(txt_pass, 1, 2);

Button btn_login = new Button("Login");
grid.add(btn_login, 1, 3);
btn_login.setOnAction(e -> {
	if(txt_user.getText().equals("")||txt_pass.getText().equals("")){
		System.out.println("Please fill the empty fields!");
	}else{
		//connect(txt_user.getText().toString(),txt_pass.getText().toString());	
		String user = txt_user.getText().toString();
		String pass = txt_pass.getText().toString();
		Connection conn;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/usms?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","");
		
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select * from admin where a_name='"+txt_user.getText().toString()+"'");
			while(rs.next()){
				//System.out.println(""+rs.getString("u_name"));
			if(user.equals(rs.getString("a_name")) && pass.equals(rs.getString("a_pass"))){
			
				System.out.println("Logged in Sucessfully!");
				primaryStage.setScene(scene2);
				cleareverything();
			}else{
				System.out.println("Invalid Username or Password!");
				
			}
		}} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		}
		
	});

scene1= new Scene(grid, 500, 350);
               
//Scene 2
GridPane grid2 = new GridPane();
grid2.setHgap(5);
grid2.setVgap(5);
grid2.setPadding(new Insets(5));

Button viewSales = new Button("Daily Sales");
Button viewStock = new Button("View Stock");
Button feeditems = new Button("Feed Items");
Button logout = new Button("Logout");

/////////Stock View

viewStock.setOnAction(e->{
	Stage showStage = new Stage();
	showStage.setTitle("Stocks");
	stocklist = new ListView();
	
	Connection conn2;
	stocklist.getItems().add("Item Name | Brand | Quantity");
	try {
		conn2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/usms?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","");
	
		Statement stmt2 = conn2.createStatement();
		ResultSet rs2 = stmt2.executeQuery("SELECT i_name,i_brand,s_quantity FROM items INNER JOIN stock WHERE items.i_id = stock.s_id");
		while(rs2.next()){
			String name = rs2.getString("i_name");
			String brand = rs2.getString("i_brand");
			String quan = rs2.getString("s_quantity");
			
			System.out.println(name+brand+quan);	
			stocklist.getItems().add(name+" | "+brand+" | "+quan);
	}
		
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	VBox myVBox = new VBox(stocklist);
	Scene stockScene = new Scene(myVBox,500,400);
	showStage.setScene(stockScene);
	showStage.show();
});


//hbox menubar
HBox hbox = new HBox(viewStock,viewSales,feeditems,logout);
hbox.setSpacing(10);
grid2.add(hbox, 0, 0);

//hbox table view
 tableView = new TableView();
TableColumn<items, ?> col1 = new TableColumn<>("Item Name");
col1.setCellValueFactory(new PropertyValueFactory<>("iname"));


TableColumn<items, ?> col2 = new TableColumn<>("Brand");
col2.setCellValueFactory(new PropertyValueFactory<>("brand"));

TableColumn<items, ?> col3 = new TableColumn<>("Category");
col3.setCellValueFactory(new PropertyValueFactory<>("category"));


TableColumn<items, ?> col4 = new TableColumn<>("Size");
col4.setCellValueFactory(new PropertyValueFactory<>("size"));

TableColumn<items, ?> col5 = new TableColumn<>("Price");
col5.setCellValueFactory(new PropertyValueFactory<>("price"));


TableColumn<items, ?> col6 = new TableColumn<>("Quantity");
col6.setCellValueFactory(new PropertyValueFactory<>("quantity"));


tableView.setMinWidth(600);
tableView.getColumns().add(col1);
tableView.getColumns().add(col2);
tableView.getColumns().add(col3);
tableView.getColumns().add(col4);
tableView.getColumns().add(col5);
tableView.getColumns().add(col6);
//vbox for insert Items
Label l1 = new Label("Item Name or Barcode");
tf1 = new ComboBox<>();
tf1.setEditable(true);
Label l3 = new Label("Item Quantity");
tf3 = new TextField();
Button addItem = new Button("Add Item");
Button remItem = new Button("Remove Item");
Button billPrint = new Button("Generate Bill");
list = new ListView<>();

///combobox
tf1.setOnKeyReleased(new EventHandler<KeyEvent>() {
    @Override
    public void handle(KeyEvent event) {
        String s = jumpTo(event.getText(), tf1.getValue(), tf1.getItems());
        if (s != null) {
        	tf1.setValue(s);
        }
    }

    String jumpTo(String keyPressed, Object object, List<String> items) {
        String key = keyPressed.toUpperCase();
        if (key.matches("^[A-Z]$")) {
            // Only act on letters so that navigating with cursor keys does not
            // try to jump somewhere.
            boolean letterFound = false;
            boolean foundCurrent = object == null;
            for (String s : items) {
                if (s.toUpperCase().startsWith(key)) {
                    letterFound = true;
                    if (foundCurrent) {
                        return s;
                    }
                    foundCurrent = s.equals(object);
                }
            }
            if (letterFound) {
                return jumpTo(keyPressed, null, items);
            }
        }
        return null;
    }	
});
try{
	Connection conn2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/usms?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","");
	Statement stmt2 = conn2.createStatement();
	ResultSet rs = stmt2.executeQuery("SELECT i_name,is_size FROM items INNER JOIN itemsizes WHERE items.i_id=itemsizes.is_it_id");
	while(rs.next()){
		tf1.getItems().addAll(rs.getString("i_name")+","+rs.getString("is_size"));
	}
	}catch(Exception ex){
		
	}

///ADD Item
addItem.setOnAction(e -> {
	list.getItems().clear();
	boolean isEmpty = tf1.getSelectionModel().isEmpty();
	if(isEmpty){
		tf1.setPromptText("Enter the Item name");
	}else if(tf3.getText().equals("")){
		tf3.setPromptText("Enter Item Quantity");
	}else{
	val = (String) tf1.getValue();
	String[] a = val.split("," , 2);
	Connection conn2;
	try {
		conn2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/usms?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","");
	
		Statement stmt2 = conn2.createStatement();
		ResultSet rs2 = stmt2.executeQuery("SELECT i_name,i_brand,i_category,is_size,is_price FROM items INNER JOIN itemsizes WHERE items.i_id=itemsizes.is_it_id AND (items.i_name='"+a[0]+"' AND itemsizes.is_size='"+a[1]+"')");
		while(rs2.next()){
			//System.out.println(""+rs.getString("u_name"));	
			   tableView.getItems().add(new items(rs2.getString("i_name"),rs2.getString("i_brand"),rs2.getString("i_category"),rs2.getString("is_size"),rs2.getString("is_price"),tf3.getText().toString()));

	}} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	}
//	   tableView.getItems().add(new items("Jane", "Deer","zz","zee","zeee","zeer"));
	
});

////remove Items
TableViewSelectionModel tbsm = tableView.getSelectionModel();
tbsm.setSelectionMode(SelectionMode.MULTIPLE);

remItem.setOnAction(e->{
	index = tbsm.getSelectedIndex();
	System.out.println(index);
	tableView.getItems().remove(index);
});

///bill print
billPrint.setOnAction(e->{
	int z =0;
	list.getItems().add("Name|Brand|Category|Size|Price|Quantity");
		for(items item : tableView.getItems()){
			 String formatted = String.format("%s %s (%s) %s %s%s%s",item.getIname(),item.getBrand(),item.getCategory(),item.getSize(),item.getPrice(),"X",item.getQuantity());
				int x = Integer.valueOf(item.getPrice());
				int y = Integer.valueOf(item.getQuantity());
				z= z+(x*y);
			 //System.out.println(formatted);	
				list.getItems().add(formatted);
				count++;
		}
		
		//System.out.print(z);
		list.getItems().add("Total Amount : "+z+" Rupees");
		tableView.getItems().clear();
});

/////////Item insert box
Label lz = new Label("Item ID");
TextField iid = new TextField();
iid.setText(getitemid());
iid.setMaxSize(180, 30);

Label la = new Label("Add Item Name:");
TextField iname = new TextField();
iname.setMaxSize(180, 30);

Label lb = new Label("Add Item Brand:");
TextField ibrand = new TextField();
ibrand.setMaxSize(180, 30);

Label lc = new Label("Add Item Category:");
ComboBox icateg = new ComboBox();
icateg.getItems().add("Cosmatics");
icateg.getItems().add("Dairy");
icateg.getItems().add("Stationary");
icateg.getItems().add("Grossery");
icateg.getItems().add("Electronics");

icateg.setMaxSize(180, 30);

Label ld = new Label("Add Item Size:");
ComboBox isize = new ComboBox();
isize.getItems().add("L");
isize.getItems().add("M");
isize.getItems().add("S");
isize.getItems().add("N");
isize.setMaxSize(180, 30);

Label le = new Label("Add Item Price:");
TextField iprice = new TextField();
iprice.setMaxSize(180, 30);

Label lf = new Label("Add Item Stock Quantity:");
TextField iquanstock = new TextField();
iquanstock.setMaxSize(180, 30);


Button itemadd = new Button("Add Item");

Button itemaddsec = new Button("Add another size");
itemadd.setOnAction(e->{
	  Statement InsSt,InsSt2,InsSt3;
	  Connection connection,connectionx,connectiony;
	  
	try {
		connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/usms?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","");  
	    
            InsSt=connection.createStatement();
            String SQLQuery = "INSERT INTO items VALUES ('"+iid.getText()+"',1,'"+iname.getText()+"','"+ibrand.getText()+"','"+icateg.getValue()+"')";
            InsSt.executeUpdate(SQLQuery);    
		    System.out.print("Data sent!");
		    connection.close();
		    connectionx = DriverManager.getConnection("jdbc:mysql://localhost:3306/usms?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","");     
		    InsSt2 = connectionx.createStatement();
		    String query2 = "INSERT INTO itemsizes (is_it_id,is_size,is_price) VALUES('"+iid.getText()+"','"+isize.getValue()+"','"+iprice.getText()+"')";
		    InsSt2.executeUpdate(query2);
		    System.out.print("Data 2 also sent!");
		    connection.close();
		    
		    connectiony = DriverManager.getConnection("jdbc:mysql://localhost:3306/usms?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","");     
		    InsSt3 = connectiony.createStatement();
		    String query3 = "INSERT INTO stock (s_id,s_quantity) VALUES('"+iid.getText()+"','"+iquanstock.getText()+"')";
		    InsSt3.executeUpdate(query3);
		    System.out.print("Data 3  sent!");
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
});
itemaddsec.setOnAction(e->{
    Connection connectionx,connectiony;
    Statement InsSt2,InsSt3;
    try {
		connectionx = DriverManager.getConnection("jdbc:mysql://localhost:3306/usms?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","");    
    InsSt2 = connectionx.createStatement();
    String query2 = "INSERT INTO itemsizes (is_it_id,is_size,is_price) VALUES('"+iid.getText()+"','"+isize.getValue()+"','"+iprice.getText()+"')";
    InsSt2.executeUpdate(query2);
    System.out.print("Data 2 also sent!");
    connectionx.close();
    
    connectiony = DriverManager.getConnection("jdbc:mysql://localhost:3306/usms?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","");     
    InsSt3 = connectiony.createStatement();
    String query3 = "INSERT INTO stock (s_id,s_quantity) VALUES('"+iid.getText()+"','"+iquanstock.getText()+"')";

		InsSt3.executeUpdate(query3);
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
    System.out.print("Data 3  sent!");
    
});




feeditems.setOnAction(e->{
	Stage stg = new Stage();
	VBox itembox = new VBox(lz,iid,la,iname,lb,ibrand,lc,icateg,ld,isize,le,iprice,lf,iquanstock,itemadd,itemaddsec);
	itembox.setAlignment(Pos.CENTER);
	itembox.setSpacing(5);
	Scene scene3 = new Scene(itembox,300,500);
	stg.setScene(scene3);
	stg.show();

});



VBox addbox = new VBox(l1,tf1,l3,tf3,addItem,remItem,billPrint,list);

addbox.setSpacing(10);
grid2.add(addbox, 1, 1);


//hbox for table
HBox htbox = new HBox(tableView);
grid2.add(htbox, 0, 1);
///logout
logout.setOnAction(e -> primaryStage.setScene(scene1));
///set scene2
scene2= new Scene(grid2,850,550);
        
        
primaryStage.setScene(scene1);
primaryStage.show();

	

	
	}

private void ShowData() {
		// TODO Auto-generated method stub

		
	}

private String getitemid(){
	Connection connection;

	try {
		connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/usms?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","");
		Statement stmt3 = connection.createStatement();
		ResultSet rs3 = stmt3.executeQuery("SELECT MAX(i_id) AS itemid FROM items");
		while(rs3.next()){
			itemid = rs3.getString(1);
		}
		//System.out.println(itemid);
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	return itemid;
}
private void cleareverything() {
		// TODO Auto-generated method stub
	list.getItems().clear();
	tableView.getItems().clear();
	tf3.setText("");
	}


private String clac(String price, String quantity) {
		// TODO Auto-generated method stub
		int x = Integer.valueOf(price);
		int y = Integer.valueOf(quantity);
		int z = x*y;
		int q = 0 ;
		for(int i = 0; i<count;i++){
			q = q+z;
		}
		return String.valueOf(q);
	}




public static void main(String[] args) {
launch(args);
}
    
}
